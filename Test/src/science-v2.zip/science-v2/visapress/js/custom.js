$(function() {
    "use strict";
    function e(n) {
        $(n).toggleClass("open")
    }
    function o() {
        f.removeClass("open");
        b.removeClass("open")
    }
    function s() {
        y.removeClass("open");
        k.removeClass("open")
    }
    function h() {
        p.removeClass("open");
        d.removeClass("open")
    }
    var f = $(".search-wrapper"), 
	y = $(".login-wrapper"), 
	p = $(".cart-wrapper"), 
	w = $(".floating-menu"), 
	ut = $(".floating-menu a"), 
	b = $(".open-search"), 
	k = $(".open-login"), 
	d = $(".open-cart"), 
	ft = $(".open-menu"), 
	et = $(".open-dropdown"), 
	ot = $(".nav-settings .nav-settings-list li"), 
	st = $(".close-menu"), i, t, g, n, c, l, a, nt, tt, u, v;
	
    k.on("click", function() {
        e($(this));
        y.toggleClass("open");
        o();
        h()
    });
    b.on("click", function() {
        e($(this));
        f.toggleClass("open");
        f.find("input").focus();
        s();
        h()
    });
    d.on("click", function() {
        e($(this));
        p.toggleClass("open");
        s();
        o()
    });
    ft.on("click", function() {
        w.addClass("expanded");
        o();
        s();
        h()
    });
    ot.on("click", function() {
        var n = $(this).closest(".nav-settings").find(".nav-settings-value");
        n.text($(this).text())
    });
    if ($("nav").hasClass("navbar-single-page"))
        ut.on("click", function() {
            w.removeClass("expanded")
        });
    et.on("click", function(n) {
        n.preventDefault();
        var t = $(this).parent().parent()
          , i = t.find(".navbar-dropdown");
        t.toggleClass("expanded");
        t.hasClass("expanded") ? i.slideDown() : i.slideUp()
    });
    st.on("click", function() {
        $("nav").find(".expanded").removeClass("expanded");
        $("nav").find(".navbar-dropdown").slideUp()
    });
    i = $("nav.navbar-fixed");
    $(document).scrollTop() > 94 && i.addClass("navbar-sticked");
    $(document).on("bind ready scroll", function() {
        var n = $(document).scrollTop();
        n >= 10 ? i.addClass("navbar-sticked") : i.removeClass("navbar-sticked")
    });        
    
    g = $(".wrapper");
    g.append($("<div class='scroll-top'><i class='icon icon-chevron-up'><\/i><\/div>"));
    n = $(".scroll-top");
    $(document).on("ready scroll", function() {
        var t = $(document).scrollTop()
          , i = $(window).scrollTop() + $(window).height() == $(document).height();
        t >= 150 ? n.addClass("visible") : n.removeClass("visible");
        i ? n.addClass("active") : n.removeClass("active")
    });
    n.on("click", function() {
        return $("html,body").animate({
            scrollTop: $("body").offset().top
        }, 1e3),
        !1
    });      
    
    if ($("nav").hasClass("navbar-single-page")) {
        v = $(".navigation-main a");
        v.on("click", function() {
            return v.removeClass("current"),
            $(this).addClass("current"),
            $("html, body").animate({
                scrollTop: $($(this).attr("href")).offset().top - $(".navigation-main").height()
            }, 500),
            !1
        });        
    }
});