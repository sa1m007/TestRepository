<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
<meta name="author" content="SINDEVO THEMES" />
<meta name="description" content="wedding html template" />
<meta name="keywords" content="the wedding date, wedding website, wedding html template, wedding design, marriage html template, engagement website" />
<title>Wedding photo creator</title>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo esc_url( get_template_directory_uri() ); ?>/style.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/intro.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/animsition.min.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/swipebox.css" />
<link href='http://fonts.googleapis.com/css?family=Clicker+Script' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,700,900' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Rouge+Script" rel="stylesheet"> 
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/owl-carousel/owl.theme.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/owl-carousel/owl.themecarousel.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/owl-carousel/owl.transitions.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/image-slider.css">
<link href="https://fonts.googleapis.com/css?family=Charm|Roboto+Condensed" rel="stylesheet"> 

</head>
<body>

<!-- Sidebar social icons start -->
<div class="icon-bar">
  <a href="#" class="facebook"><i class="fa fa-facebook"></i></a> 
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a> 
  <a href="#" class="google"><i class="fa fa-google"></i></a> 
  <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a> 
</div>
<!-- Sidebar social icons end -->

<!--Start of body container-->
<div id="container" class="container intro-effect-push animsition"> 

<!-- Down button start-->
<a href="index.html#sec"><button class="trigger downanimated bounce"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/arrow-down.png" alt="Scroll Down" title="Scroll Down"/></button></a>
<!-- Down button end-->

<!-- Primary Menu start -->
<?php
	$args = array(
	'theme_location' 	=> 'primary_menu',
	'menu' 				=> 'Primary Menu',
	'container'       	=> 'nav',
	'container_class' 	=> 'menugray sticky',
	'container_id'    	=> 'main_menu'	
	);
	
	wp_nav_menu($args);
?>
<!-- Primary Menu end -->