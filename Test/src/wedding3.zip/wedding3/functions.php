<?php
function register_theme_menus(){
	
	register_nav_menu( 'primary_menu','Primary Menu' );
	
}
add_action('init','register_theme_menus');
