<?php get_header(); ?>

<!-- Latest stories start -->
<div class="section_centered">
  
		<div id="sec" class="centered_title">
			<h2>LATEST <span>journal</span> STORIES</h2>
			<p class="under_title_descr"><span>Love is composed of a single soul inhabiting two bodies.</span></p>
		</div>	
  
       <div class="latest_posts">


              <div class="blog_post left13 block" data-move-y="300px" data-move-x="-200px">
                    <div class="post_thumb"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/lake-como-wedding-galley.jpg"alt="" title="" /></div>
					
                   <center><div class="post_date">Pre-Wedding Photography</div></center>
                   <h2><a href="blog-single.html" class="fade-page">We are among the pioneers in the world of modern pre-wedding photography in India. We have introduced the customized Pre-wedding Photography packages like Love in the Rain (A rain themed pre-wedding photography). </a></h2>
                  <center> <a href="#" class="post_read_more fade-page">READ MORE</a>  </center>
              </div>
              <div class="blog_post left13 block" data-move-y="300px" data-move-x="0px">
                    <div class="post_thumb"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/couple-2381494_1920.jpg" alt="" title="" /></div>
                        			
                   <center><div class="post_date">Indian Wedding Photography</div></center>
                   <h2><a href="blog-single.html" class="fade-page">From a humble start in 2015, We are now considered a one-stop solution for all your photography requirements no matter how small or how big is the wedding.We are equipped with the latest photographic gear, </a></h2>
                  <center> <a href="blog-single.html" class="post_read_more fade-page">READ MORE</a> </center> 
              </div>
              <div class="blog_post left13_last block" data-move-y="300px" data-move-x="200px">
                    <div class="post_thumb"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/paris-wedding-photographers.jpg" alt="" title="" /></div>
                        			
                  <center> <div class="post_date">Maternity Photography</div></center>
                   <h2><a href="#" class="fade-page">Maternity photography is a new vogue in India. This is a perception where women are advancing to be creatively snapped while they were expectant.Its a trend now were shutterbugs capture motherhood in a special </a></h2>
                  <center> <a href="#" class="post_read_more fade-page">READ MORE</a>  </center>
              </div>

            <div class="read_more_full"><a href="#" class="fade-page"><span style="color:#000;">VIEW ALL POSTS</span></a></div>
           
      </div>
</div>
<!-- Latest stories end -->

<div class="content">
     
	<!-- Full Width Images start -->
	<div id="countdown_home" class="countdown_container" style="background-color:#000; ">
		<div class="countdown_container_inner block" data-move-y="200px" data-move-x="0px">
			<center>  <h3 style="color:#fff;">We Capture Moments Which are Gone Forever, Impossible to Reproduce</h3></center>
			<img src="data1/<?php echo esc_url( get_template_directory_uri() ); ?>/images/weddingdresses1485984_1920.jpg">
			<img src="data1/<?php echo esc_url( get_template_directory_uri() ); ?>/images/couple2381494_1920.jpg">
			<img src="data1/<?php echo esc_url( get_template_directory_uri() ); ?>/images/weddingdresses1486004_1920.jpg">				
		</div>          				
	</div>
	<!-- Full Width Images end -->		
	
	<!-- Image gallery start -->	
    <div id="photos_home" class="section_full">
			
		<div class="centered_title">
		<h2>Our <span>Image</span> Gallary</h2>
		<p class="under_title_descr"><span>Love is composed of a single soul inhabiting two bodies.</span></p>
		</div>				
		<div class="photos_grid">
			<figure class="effect-photos photos14 block" data-move-x="-500px" data-rotate="90deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p7.jpg">
				<figcaption>
					<h2>Our First <span>Kiss</span></h2>
					<p>Whatever you happen to be feeling at the moment is fine with them..</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p7.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-y="200px" data-move-x="-200px" data-rotate="45deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p9.jpg"alt="img01"/>
				<figcaption>
					<h2>Romantic First <span>Date</span></h2>
					<p>Whatever you happen to be feeling at the moment is fine with them..</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p9.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-y="200px" data-move-x="200px" data-rotate="-45deg">
            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p10.jpg" alt="img01"/>
				
				<figcaption>
					<h2>Vacation <span>Adventures</span></h2>
					<p>Love is composed of a single soul inhabiting two bodies.</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p10.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-x="500px" data-rotate="-90deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p8.jpg" alt="img01"/>
				<figcaption>
					<h2>Beautiful <span>Soul</span></h2>
					<p>Whatever you happen to be feeling at the moment is fine with them..</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p8.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-x="-500px" data-rotate="90deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p11.jpg"alt="img15"/>
				<figcaption>
					<h2>Lovely <span>Jenifer</span></h2>
					<p>Love is composed of a single soul inhabiting two bodies.</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p11.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-y="200px" data-move-x="-200px" data-rotate="45deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p12.jpg"alt="img01"/>
				<figcaption>
					<h2>Soul <span>Mates</span></h2>
					<p>Whatever you happen to be feeling at the moment is fine with them..</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p12.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-y="200px" data-move-x="200px" data-rotate="-45deg">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p14.jpg" alt="img01"/>
				<figcaption>
					<h2>Travel The <span>World</span></h2>
					<p>Love is composed of a single soul inhabiting two bodies.</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/p14.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
			<figure class="effect-photos photos14 block" data-move-x="500px" data-rotate="-90deg">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/pic5.jpg" alt="img01"/>
				<figcaption>
					<h2>Wedding <span>Rings</span></h2>
					<p>Whatever you happen to be feeling at the moment is fine with them..</p>
					<strong>DETAILS</strong>
					<a rel="gallery-1" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/pic5.jpg" class="swipebox">View more</a>
				</figcaption>			
			</figure>
		</div>		
		<div class="read_more_full"><a href="#"  style="color:#DD1619;"><span>VIEW ALL PHOTOS</span></a></div>		
		<div class="clear"></div>		
        
	</div>
	<!-- Image gallery end -->        
</div><!-- End of content-->

<?php get_footer(); ?>