
<!-- Footer start -->
 <div class="footer"> 
<!-- Start of Footer Container --> 
 <div class="container">       

  <!-- Footer column 1 -->
  <div class="footer_box">

  <ul>
    <h3 style="color:#fff;">OUR SERVICES</h3>
  <li><a href="#"> <i class="fa fa-chevron-right"></i>  India Wedding Photographer</a></li>

   
   <li><a href="#"> <i class="fa fa-chevron-right"></i> Candid wedding photography</a></li>
   <li><a href="#">  <i class="fa fa-chevron-right"></i>Cinematic wedding videos</a></li>
    <li><a href="#"> <i class="fa fa-chevron-right"></i>Pre wedding couple shoot</a></li>
    <li><a href="#"> <i class="fa fa-chevron-right"></i>Destination wedding photography</a></li>
   <li><a href="#"> <i class="fa fa-chevron-right"></i> maternity photography</a></li>
</li>
  </ul>
  </div>
  <!-- Footer column 2 -->
   <div class="footer_box">
    <ul>
    <h3 style="color:#fff;">OUR SERVICES</h3>
  <li><a href="#"><i class="fa fa-chevron-right"></i>  Wedding Photography Mumbai</a></li>

   
   <li><a href="#"><i class="fa fa-chevron-right"></i>   Wedding Photography Bangalore</a></li>
   <li><a href="#"><i class="fa fa-chevron-right"></i>  Wedding Photography Kolkata</a></li>
    <li><a href="#"> <i class="fa fa-chevron-right"></i> Bengali Wedding Photography</a></li>
    <li><a href="#"> <i class="fa fa-chevron-right"></i> Muslim Wedding</a></li>
   <li><a href="#"> <i class="fa fa-chevron-right"></i> Non Bengali Wedding</a></li>
   <li><a href="#"> <i class="fa fa-chevron-right"></i> Travel Photography</a></li>
</li>
  </ul>
   </div>
   
   <!-- Footer column 3 -->
   <div class="footer_box">
      
		 <h3 style="color:#fff;"> CONTACTS US</h3>
		 <P style="color:#fff;">Email id: wpc2014offical@gmail.com</P>
		 <P style="color:#fff;">Helpline Numbers (8AM to 10PM): +91- 8910479360, 9874523759 </P>
		 <P style="color:#fff;"> Corp Office / Postal Address

		23/15 Naktala Lane kolkata- 700047 West Bengal India</P>
		<div class="social_link">

		<i class="fa fa-facebook" ></i> 
		<i class="fa fa-youtube" style="padding-left:15px; background-color: #c4302b;"></i> 
		<i class="fa fa-twitter" style="padding-left:15px; background-color:#38A1F3;"></i> 
		<i class="fa fa-linkedin" style="padding-left:15px;background-color: #0077B5;"></i>
		<i class="fa fa-google" style="padding-left:15px; background-color:#CF0C0F;"></i>
		 </div>        
	</div>

	 <!-- Footer column 4 -->
    <div class="footer_box" style="margin-top:30px; margin-bottom:30px;">
         <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7373.695284751575!2d88.368366!3d22.472359!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x96878552d16ff620!2sWedding+Photo+Creators!5e0!3m2!1sen!2sin!4v1545891964296" width="250" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
  		
</div> <!-- End of Footer Container -->
<div class="footer color_white"
<center> © 2018 Wedding Photo Creators. All rights reserved <br><br>
<a href="#" id="back-to-top" title="Back to top"><i class="fa fa-camera" style="font-size:40px; padding-top:10px;"></i></a>
</div>  
    
</div> 
<!-- End of Footer -->	

</div>
<!--End of body container-->


<!-- jQuery -->
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/animsition.min.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/menu.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.countdown.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.swipebox.min.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/owl-carousel/owl.carousel.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/velocity.min.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/classie.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/scrollheader.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.arctext.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.smoove.js"></script>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/custom.js"></script>
<script type="text/javascript">
$("#main_menu").menumaker({
format: "multitoggle",
sticky: true
});
</script>
<script type="text/javascript">
$( document ).ready(function() {      
    var isMobile = window.matchMedia("only screen and (max-width: 1300px)");

    if (!isMobile.matches) {
       $('.block').smoove({offset:'2%'});
    }
 });
</script>
</body>
</html>